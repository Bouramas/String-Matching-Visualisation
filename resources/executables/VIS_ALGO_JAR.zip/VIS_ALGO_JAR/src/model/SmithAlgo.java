package model;

import com.google.common.base.CharMatcher;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.StageStyle;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by Bouramas on 8/3/15.
 */
public class SmithAlgo extends Visualisable {
    private ListView indexList,failList, patternList;
    protected static final int CELL_A_WIDTH = 100;
    private Pane backPane;
    private int[] qsTable, bmTable;


    /****************************************************
     * Default Constructor
     ***************************************************/
    public SmithAlgo( Rectangle textRectA, Rectangle patternRectA, Rectangle textRectB, Rectangle patternRectB,
                      Label patternLabel, ListView codeView, ListView infoView, ListView indexList, ListView patternList, ListView failList, Pane backPane, ListView tableInfoView ) {
        super(textRectA, patternRectA, textRectB, patternRectB, patternLabel, codeView, infoView);

        this.indexList = indexList;
        this.patternList = patternList;
        this.failList = failList;
        this.backPane = backPane;

        // Populate ListViews with the appropriate data
        loadAlgoData(SM_TXT);
        // Populate the tableInfo ListView
        Path tableInfoPath = Paths.get(DATA_ADDRESS + SM_TXT + "TableInfo.txt");
        tableInfoView.setItems(getData(tableInfoPath));
        // Disable User selection
        tableInfoView.setFocusModel(null);
    }

    public SequentialTransition getAnimation() {

        // The centralAnimation which will store all sub-Animations
        SequentialTransition animSequence = new SequentialTransition();
        // Initialize X-coordinates of the Rectangles
        this.setXCoordinates();
        // Store the searchText and patternText length
        int m = pattern.length, n = text.length;
        // Initialize all indexes at 0
        int sp = 0, i = 0, j = 0;


        // While pattern hasn't been found and not reached end of text/string
        while ( sp <= n-m && j < m ) {

            animSequence.getChildren().addAll(
                    new PauseTransition( HALF_SEC ),
                    highlightCodeRow( ZERO,6,7 )
            );

            if (text[i] == pattern[j]) { // if chars match

                animSequence.getChildren().addAll(
                        highlightCodeRow( HALF_SEC, 8 ),
                        highlightCodeRow( HALF_SEC , 9,10 ),
                        hideOrangeRect()
                );

                // Show the other Rectangles
                if (j == 0) animSequence.getChildren().add( showGreenRect() );
                    // else increase the size to highlight one more character
                else animSequence.getChildren().add( setRectBWidth( j + 1 ) );
                // Pause for half a second
                animSequence.getChildren().add( new PauseTransition( ONE_SEC ) );

                i++; j++; // move on in text and pattern

                if (sp <= n - m && j < m) {
                    animSequence.getChildren().addAll(
                            moveOrangeRect(rectWidth),
                            new PauseTransition(HALF_SEC)
                    );
                } else {
                    animSequence.getChildren().add(highlightCodeRow( HALF_SEC, 16 ));
                    if (j == m ) animSequence.getChildren().add( highlightCodeRow( HALF_SEC, 16, 17) );
                    else animSequence.getChildren().add( highlightCodeRow( HALF_SEC, 18, 19) );
                }

            }
            else { // if there is a mismatch
                // Add the transitions to the general sequence
                animSequence.getChildren().addAll(
                        highlightCodeRow( HALF_SEC, 11 ),
                        highlightCodeRow( HALF_SEC, 12,13,14 ),
                        mismatchTransition() );
                if (j > 0) animSequence.getChildren().addAll(moveOrangeRect(-j * rectWidth));

                int jump = Math.max(qsTable[ text[ sp + m ] ], bmTable[ text[ sp + m - 1 ] ] );

                animSequence.getChildren().addAll(
                        new ParallelTransition(
                                moveRectsA( rectWidth * jump, ONE_SEC ),
                                moveRectsB( rectWidth * jump, ONE_SEC ),
                                moveLabel( rectWidth * jump, ONE_SEC ) ),
                        setRectBWidth( 1 ) );

                j = 0; // start again in string
                sp += jump; // advance search index
                i = sp; // back up in text to new search index
            }
        }
        // Store the result
        result = ( j == m ? sp : -1 );

        return animSequence;
    }

    /*****************************************************************************************
     * If c is in P, qsTable(c) is equal to the patternLength minus the index of the
     * qsTable (right-most) occurrence of c in P.
     * Otherwise, we can conventionally define qsTable(c) = patternLength + 1
     ****************************************************************************************/
    private void createQSArray() {

        int m = pattern.length;
        qsTable = new int[256];

        // If a character doesn't exist in P
        for (int i = 0; i < 256; i++)
            qsTable[i] = m + 1;
        // If it does, calculate its qsTable occurrence
        for (int i = 0; i < m; i++)
            qsTable[ pattern[i] ] = m - i;
    }

    /*****************************************************************************************
     * Horspool shift function
     ****************************************************************************************/
    private void createHPArray() {

        bmTable = new int[256];
        int m = pattern.length;

        // If a character doesn't exist in P
        for (int i = 0; i < 256; i++)
            bmTable[i] = m;
        for (int i = 0; i < m - 1; i++)
            bmTable[ pattern[i] ] = m - i - 1;
    }


    /*************************************************************************
     * Populate the lists
     ************************************************************************/
    private void populateLists() {
        ObservableList<String> charRow = FXCollections.observableArrayList(" Char c ");
        ObservableList<String> quickSRow = FXCollections.observableArrayList(" QS[c]  ");
        ObservableList<String> horspoolRow = FXCollections.observableArrayList(" HP[c]  ");

        int m = pattern.length;
        for ( int i = 0; i < 256; i++ ) {
            if ( !(qsTable[i] > m) ) {
                charRow.add((char) (i) + "");
                quickSRow.add(qsTable[i] + "");
                horspoolRow.add(bmTable[i] + "");
            }
        }

        // For the rest qsTable(c) = patternLength + 1
        charRow.add("REST");
        quickSRow.add(" " + (m + 1) + " ");
        horspoolRow.add(" " + m + " ");


        // Populate lists
        indexList.setItems(charRow);
        patternList.setItems(quickSRow);
        failList.setItems(horspoolRow);
        // Disable user Selection/Focus
        indexList.setFocusModel(null);
        patternList.setFocusModel(null);
        failList.setFocusModel(null);

        int cellsWidth = 20 + CELL_A_WIDTH + ( CELL_WIDTH * charRow.size() );
        // Adjust the width of the lists based on the length of the pattern
        indexList.setPrefWidth( cellsWidth );
        patternList.setPrefWidth( cellsWidth );
        failList.setPrefWidth( cellsWidth );
        backPane.setPrefWidth( PANE_PADDING + cellsWidth );

        indexList.setStyle( VISIBLE );
        patternList.setStyle( VISIBLE );
        failList.setStyle( VISIBLE );
    }

    /****************************************************
     * Set the pattern text and populate the list
     * @param pattern - the search text
     * @return boolean - succesful or not
     ***************************************************/
    @Override public boolean setPatternText( String pattern ) {

        // Ensure that only ASCII Characters are used
        if (!CharMatcher.ASCII.matchesAllOf(pattern) ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UNDECORATED);
            alert.setHeaderText("Error - Non-ASCII character identified: " + pattern);
            alert.setContentText("Smith's algorithm works with a " +
                    "specific charset and currently accepts only ASCII characters");
            alert.showAndWait();
            return false;
        }

        super.setPatternText(pattern);

        if ( !pattern.isEmpty() ){
            this.createQSArray();
            this.createHPArray();
            this.populateLists();
        }
        return true;
    }
}
