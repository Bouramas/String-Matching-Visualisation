package model;

import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by Bouramas on 8/3/15.
 */
public class NotSoNaiveAlgo extends Visualisable {

    private ListView listOne, listTwo;
    private Pane backPane;

    /****************************************************
     * Default Constructor
     ***************************************************/
    public NotSoNaiveAlgo( Rectangle tA, Rectangle pA, Rectangle tB, Rectangle pB, Label label, ListView codeView, ListView infoView,
                           ListView listOne, ListView listTwo, Pane backPane, ListView tableInfoView) {
        super(tA, pA, tB, pB, label, codeView, infoView);

        this.listOne = listOne;
        this.listTwo = listTwo;
        this.backPane = backPane;

        // Populate ListViews with the appropriate data
        loadAlgoData(NSN_TXT);
        // Populate the tableInfo ListView
        Path tableInfoPath = Paths.get( DATA_ADDRESS + NSN_TXT + "TableInfo.txt" );
        tableInfoView.setItems( getData( tableInfoPath ) );
        // Disable User selection
        tableInfoView.setFocusModel(null);
    }

    /*****************************************************************************************
     * Create the animation
     * @return SequentialTransition the sequence of animations
     ****************************************************************************************/
    @Override public SequentialTransition getAnimation()
    {

        // The centralAnimation which will store all sub-Animations
        SequentialTransition animSequence = new SequentialTransition();
        // Initialize X-coordinates of the Rectangles
        this.setXCoordinates();

        // length of string (m) and text (n)
        int m = pattern.length, n = text.length;
        // current position in text(i)  and string (j)
        int j = 2, i = 1;
        // starting position in text
        int sp = 0;

        // Preprocessing
        int k = (pattern[0] == pattern[1]? 2 : 1);
        int l = (pattern[0] == pattern[1]? 1 : 2);

        // Reset result
        result = -1;

        // Move the orange rectangles at the second char of the string
        animSequence.getChildren().addAll(
                new ParallelTransition(
                        moveRectsA(rectWidth, Duration.ONE),
                        moveRectsB(rectWidth, Duration.ONE)
                ),
                highlightCodeRow(ZERO, 8,9), // ---------------to be changed
                new PauseTransition(ONE_SEC)
        );

        // while we have not reached the end of text and a result hasn't been found
        while ( sp <= n - m && result < 0 )
        {
            // If there is a match
            if ( pattern[1] == text[i] )
            {

                animSequence.getChildren().addAll(
                        hideOrangeRect(),
                        showGreenRect(),
                        new PauseTransition( ONE_SEC )
                        );

                if (m > 2) // move to the next char on the right - otherwise the first char must be checked
                animSequence.getChildren().addAll(
                        moveOrangeRect(rectWidth),
                        new PauseTransition(HALF_SEC)
                );

                // Check the rest of the characters till the end of the pattern
                while ( (j < m) && pattern[j] == text[i + 1] ) {
                    animSequence.getChildren().addAll(
                            hideOrangeRect(),
                            setRectBWidth(j), // Highlight one more character
                            new PauseTransition( HALF_SEC ) // Pause for half a second
                    );
                    j++; i++; // move on in text and pattern

                    if (j < m){
                        animSequence.getChildren().addAll(
                                moveOrangeRect(rectWidth),
                                new PauseTransition(HALF_SEC)
                        );
                    }
                }

                // if we compared all chars till the end of the pattern
                // and the first characters of the pattern and text match
                if ( j == m ) {

                    animSequence.getChildren().addAll(
                            new PauseTransition( ONE_SEC ), // Pause for half a second
                            moveOrangeRect((1 - m) * rectWidth),
                            new PauseTransition(HALF_SEC)
                    );

                    if( pattern[0] == text[sp] ){
                        animSequence.getChildren().addAll(
                                hideOrangeRect(),
                                setRectBWidth( m ),
                                moveRectsB(-rectWidth, Duration.ONE),
                                new PauseTransition( HALF_SEC )
                        );
                        result = sp; // result found
                    } else
                    {
                        animSequence.getChildren().addAll(
                                mismatchTransition(),
                                new ParallelTransition(
                                        moveRectsA(rectWidth * ( l+1), ONE_SEC),
                                        moveRectsB(rectWidth * l, ONE_SEC),
                                        moveLabel(rectWidth * l, ONE_SEC)
                                ),
                                setRectBWidth( 1 )
                        );

                        j = 2; //reset pattern index
                        sp += l; // move starting position of text
                        i = sp + 1; // reset text index
                    }
                } else {
                    animSequence.getChildren().addAll(
                            mismatchTransition(),
                            new ParallelTransition(
                                    moveRectsA(rectWidth * (l-j+1), ONE_SEC),
                                    moveRectsB(rectWidth * l, ONE_SEC),
                                    moveLabel(rectWidth * l, ONE_SEC)
                            ),
                            setRectBWidth( 1 )
                    );

                    j = 2; //reset pattern index
                    sp += l; // move starting position of text
                    i = sp + 1; // reset text index
                }
            }
            else // if there is a mismatch
            {
                sp += k; // move starting position of text
                i += k; // move on in text

                animSequence.getChildren().addAll(
                        mismatchTransition(),
                        highlightCodeRow( HALF_SEC, 14, 17 ),
                        highlightCodeRow( HALF_SEC, 18,19 ), // ------------------------------------change
                        new ParallelTransition(
                                moveRectsA(rectWidth * k, ONE_SEC),
                                moveRectsB(rectWidth * k, ONE_SEC),
                                moveLabel(rectWidth * k, ONE_SEC )
                        )
                );
            }
        }
        return animSequence;
    }

    /*************************************************************************
     * Populate the list with the BoyerMoore algorithm's lastChar array
     ************************************************************************/
    private void populateLists() {
        ObservableList<String> firstRow = FXCollections.observableArrayList(" k ");
        ObservableList<String> secondRow = FXCollections.observableArrayList( " l " );

        // Calculate the k and l
        int k = (pattern[0] == pattern[1]? 2 : 1);
        int l = (pattern[0] == pattern[1]? 1 : 2);
        // Add them to the table
        firstRow.add(k + "");
        secondRow.add(l + "");

        // Populate lists
        listOne.setItems(firstRow);
        listTwo.setItems(secondRow);
        // Disable user Selection/Focus
        listOne.setFocusModel(null);
        listTwo.setFocusModel(null);

        int cellsWidth = 3 * CELL_WIDTH;
        // Adjust the width of the lists based on the length of the pattern
        listOne.setPrefWidth(cellsWidth);
        listTwo.setPrefWidth(cellsWidth);

        backPane.setPrefWidth(PANE_PADDING + cellsWidth);
        backPane.setPrefHeight(100);

        listOne.setStyle(VISIBLE);
        listTwo.setStyle(VISIBLE);
    }

    /****************************************************
     * Set the pattern text and populate the list
     * @param pattern - the search text
     * @return boolean - succesful or not
     ***************************************************/
    @Override public boolean setPatternText( String pattern ) {
        int patternLength = pattern.length();
        // Ensure that only ASCII Characters are used
        if (patternLength < 2) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initStyle(StageStyle.UNDECORATED);
            alert.setHeaderText("Minimum character length is 2.");
            alert.setContentText("The Not So Naive algorithm works only for" +
                    "patterns greater than 2 characters. Blank spaces were automatically added.");
            alert.showAndWait();
            // Add extra spaces accordingly
            pattern += (patternLength == 0 ? "  " : " ");
        }

        super.setPatternText(pattern);

        if ( !pattern.isEmpty() ) {
            this.populateLists();
        }

        return true;
    }


}
