package model;

import com.google.common.base.CharMatcher;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Rectangle;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import mainApp.MainController;

import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * Created by Bouramas on 7/20/15.
 */
public class BoyerMooreAlgo extends Visualisable {

    private ListView indexList, patternList;
    protected static final int CELL_A_WIDTH = 100;
    private Pane backPane;
    private int[] last;

    
    /****************************************************
     * Default Constructor
     ***************************************************/
    public BoyerMooreAlgo( Rectangle tA, Rectangle pA, Rectangle tB, Rectangle pB, Label label, ListView codeView, ListView infoView,
                           ListView indexList, ListView patternList, Pane backPane, ListView tableInfoView) {
        super(tA, pA, tB, pB, label, codeView, infoView);

        this.indexList = indexList;
        this.patternList = patternList;
        this.backPane = backPane;

        // Populate ListViews with the appropriate data
        loadAlgoData(BM_TXT);
        // Populate the tableInfo ListView
        Path tableInfoPath = Paths.get(DATA_ADDRESS + BM_TXT + "TableInfo.txt");
        tableInfoView.setItems(getData(tableInfoPath));
        // Disable User selection
        tableInfoView.setFocusModel(null);
    }

    public SequentialTransition getAnimation() {
        // The centralAnimation which will store all sub-Animations
        SequentialTransition animSequence = new SequentialTransition();
        // Initialize X-coordinates of the Rectangles
        this.setXCoordinates();
        // length of pattern and text
        int patLength = pattern.length, textLength = text.length;
        // current position in text and pattern
        int i = patLength-1, j = patLength-1;
        int sp = 0; // current starting position of string in text


        // Move the orange rectangles at the end of the string
        animSequence.getChildren().addAll(
                new ParallelTransition(
                    moveRectsA(rectWidth * i, Duration.ONE),
                    moveRectsB(rectWidth * i, Duration.ONE)
                ),
                highlightCodeRow(ZERO, 8,9),
                new PauseTransition(ONE_SEC)
        );

        while (sp <= textLength-patLength && j >= 0) {

            if ( text[i] == pattern[j] ) { // current characters match

                animSequence.getChildren().addAll(
                           highlightCodeRow( HALF_SEC, 10 ),
                           highlightCodeRow( HALF_SEC, 11,12 ),
                           hideOrangeRect()
                    );

                if ( j == ( patLength - 1 ) ) // Show the green Rectangles and pause for half indexList second
                    animSequence.getChildren().addAll(
                           setRectBWidth( 1 ),
                           showGreenRect(),
                           new PauseTransition( HALF_SEC )
                    );
                else if ( j < ( patLength - 1 ) )  // else double the size
                    animSequence.getChildren().addAll(
                           setRectBWidth( patLength - j ),
                           moveRectsB(-rectWidth, Duration.ONE),
                           new PauseTransition( HALF_SEC )
                    );

                if ( j != 0 && j < textLength ) // if match not found and text not finished
                    animSequence.getChildren().addAll(
                           moveOrangeRect( -rectWidth ),
                           new PauseTransition( HALF_SEC )
                    );

                i--; // move back in text
                j--; // move back in string
            }
            else { // current characters do not match

                int spIncrement = Math.max(1, j - last[text[i]]);

                animSequence.getChildren().addAll(
                        highlightCodeRow( HALF_SEC, 13 ),
                        highlightCodeRow( HALF_SEC, 14,15,16,17 ),
                        mismatchTransition(), // Make Orange Rect Red for 0.5s, and make it orange again
                        new ParallelTransition(
                                moveRectsBasedLabel( (spIncrement + patLength-1) * rectWidth, HALF_SEC ),
                                moveLabel( spIncrement * rectWidth, ONE_SEC )
                        ),
                        setRectBWidth(1)
                );

                sp += spIncrement;
                i += (patLength - Math.min(j, 1 + last[text[i]]));
                j = patLength-1; // return to end of string
            }

            animSequence.getChildren().addAll( highlightCodeRow( ZERO, 8,9 ), new PauseTransition( HALF_SEC ) );
        }

        animSequence.getChildren().add( highlightCodeRow( HALF_SEC, 19 ) );
        if (j < 0) { // occurrence found yes/no
            animSequence.getChildren().add( highlightCodeRow( HALF_SEC, 19,20 ) );
            result = sp;
        }
        else {
            animSequence.getChildren().add( highlightCodeRow( HALF_SEC, 21,22 ) );
            result = -1;
        }

        return animSequence;
    }

    /*****************************************************************************************
     * If c is in P, last(c) is the index of the last (right-most) occurence of c in P.
     * Otherwise, we can conventionally define last(c) = -1
     ****************************************************************************************/
    private void createLastCharArray() {

        last = new int[256];

        for (int i = 0; i < 256; i++)
            last[i] = -1;

        for (int i = 0; i < pattern.length; i++)
            last[ pattern[i] ] = i;
    }


    /*************************************************************************
     * Populate the list with the BoyerMoore algorithm's lastChar array
     ************************************************************************/
    private void populateLists() {
        ObservableList<String> charRow = FXCollections.observableArrayList( "  Char c " );
        ObservableList<String> lastIndexRow = FXCollections.observableArrayList( " last[c] " );

        for ( int i = 0; i < 256; i++ ) {
            if ( !(last[i] < 0) ) {
                charRow.add((char) (i) + "");
                lastIndexRow.add(last[i] + "");
            }
        }

        // For the rest last(c) = -1
        charRow.add("REST");
        lastIndexRow.add(" -1 ");

        // Populate lists
        indexList.setItems(charRow);
        patternList.setItems(lastIndexRow);
        // Disable user Selection/Focus
        indexList.setFocusModel(null);
        patternList.setFocusModel(null);

        int cellsWidth = 20 + CELL_A_WIDTH + ( CELL_WIDTH * charRow.size() );
        // Adjust the width of the lists based on the length of the pattern
        indexList.setPrefWidth(cellsWidth );
        patternList.setPrefWidth( cellsWidth );

        backPane.setPrefWidth(PANE_PADDING + cellsWidth);
        backPane.setPrefHeight(100);

        indexList.setStyle(VISIBLE);
        patternList.setStyle( VISIBLE );
    }

    /****************************************************************************
     * Set the pattern text and populate the list if text is allowed
     * @param pattern - the search text
     * @return boolean - succesful or not
     ***************************************************************************/
    @Override public boolean setPatternText( String pattern ) {

        // Ensure that only ASCII Characters are used
        if (!CharMatcher.ASCII.matchesAllOf(pattern) ) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initStyle(StageStyle.UNDECORATED);
            alert.setHeaderText("Error - Non-ASCII character identified: " + pattern);
            alert.setContentText("The Boyer Moore algorithm works with a " +
                    "specific charset and currently accepts only ASCII characters");
            alert.showAndWait();
            return false;
        }

        super.setPatternText(pattern);

        if ( !pattern.isEmpty() ){
            this.createLastCharArray();
            this.populateLists();
        }

        return true;
    }
}
