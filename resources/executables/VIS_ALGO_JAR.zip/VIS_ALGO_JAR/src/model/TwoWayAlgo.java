package model;


import com.google.common.base.CharMatcher;
import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.shape.Rectangle;
import javafx.stage.StageStyle;
import javafx.util.Duration;

import java.util.Arrays;
import java.util.Set;

/**
 * Created by Bouramas on 8/4/15.
 */
public class TwoWayAlgo extends Visualisable {

    private int[] limits1;
    private int[] limits2;


    /****************************************************
     * Constructor
     *
     * @param textRectA    - search text Rectangle (trailing)
     * @param patternRectA - pattern Rectangle (trailing)
     * @param textRectB    - search text Rectangle (leading)
     * @param patternRectB - pattern Rectangle (leading)
     * @param patternLabel - the pattern label
     * @param codeView
     * @param infoView
     ***************************************************/
    public TwoWayAlgo(Rectangle textRectA, Rectangle patternRectA, Rectangle textRectB, Rectangle patternRectB, Label patternLabel, ListView codeView, ListView infoView) {
        super(textRectA, patternRectA, textRectB, patternRectB, patternLabel, codeView, infoView);

        // Populate ListViews with the appropriate data
        loadAlgoData(TW_TXT);
    }


    public SequentialTransition getAnimation(){

        // The centralAnimation which will store all sub-Animations
        SequentialTransition animSequence = new SequentialTransition();
        // Initialize X-coordinates of the Rectangles
        this.setXCoordinates();
        // Reset result
        result = -1;
        // length of pattern (m) and text (n)
        int m = pattern.length, n = text.length;
        int sp = 0; // starting position in text
        int j; // position in pattern
        // find the maximum suffix and period
        int l,period;
        // choose max suffix from the two orderings
        if (limits1[0] > limits2[0]){
            l = limits1[0]; period = limits1[1];
        } else {
            l = limits2[0]; period = limits2[1];
        }

        // next check if first part of pattern (up to l-1) is a suffix of the second
        boolean isSuffix = false;

        if ( l < (n/2) ) { // need first part to be smaller
            int k = l; // then check if it is a suffix
            while ( k >= 0 && pattern[k] == pattern[ ( m-1 ) - ( l-k) ] ) { k--; }
            if ( k < 0 ) isSuffix = true; // is a suffix
        }

        // Move the orange rectangles at the beginning of the suffix
        animSequence.getChildren().addAll( new ParallelTransition( moveRectsA(rectWidth * (l+1), Duration.ONE), moveRectsB(rectWidth * (l+1), Duration.ONE) ), new PauseTransition(ONE_SEC) );

        if (isSuffix)
        { // first part of pattern is suffix of second
            int s = -1; // memory used for new starting position

            // while we have not reached the end of text and a result hasn't been found
            while ( sp <= n-m && result < 0 ) {
                //--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->SEARCH FORWARDS
                j = Math.max(l,s) + 1; // starting position in pattern
                while ( j < m && pattern[j] == text[sp+j] ) { // check current chars
                    // Hide the orange rectangles
                    animSequence.getChildren().addAll( hideOrangeRect() );
                    // Show the other green Rectangles
                    if (j == (Math.max(l,s) + 1))
                        animSequence.getChildren().add( showGreenRect() );
                    // else increase the size to highlight one more character
                    else animSequence.getChildren().add( incrementRectBWidth() );
                    // Pause for half a second
                    animSequence.getChildren().add( new PauseTransition( ONE_SEC ) );
                    j++; // move to next position in pattern

                    if ( j < m )
                        animSequence.getChildren().addAll(
                                moveOrangeRect(rectWidth),
                                new PauseTransition(HALF_SEC)
                        );
                } //--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->SEARCH FORWARDS

                // if end of pattern reached
                if (j >= m) {
// <-----<-----<-----<-----<-----<-----<-----<------<------<-----<------<------<-----<------<------<-----SEARCH BACKWARDS
                    j = l; // starting position in pattern

                    animSequence.getChildren().addAll( moveOrangeRect( ( l - (m-1) ) * rectWidth ), new PauseTransition( HALF_SEC ) );

                    while ( j > s && pattern[j] == text[sp+j]) { // check current chars
                        animSequence.getChildren().addAll( hideOrangeRect(), setRectBWidth( m - j ), moveRectsB(-rectWidth, Duration.ONE), new PauseTransition( HALF_SEC ) );

                        if ( j != 0 && j < m ) // if match not found and text not finished
                        animSequence.getChildren().addAll( moveOrangeRect(-rectWidth), new PauseTransition( HALF_SEC ) );

                        j--; // move to previous position in pattern
                    }
// <-----<-----<-----<-----<-----<-----<-----<------<------<-----<------<------<-----<------<------<-----SEARCH BACKWARDS
                    if (j<=s) { // if match found
                        result = sp;
                        break;
                    }
// ----x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-------MISMATCH BACKWARDS
                    animSequence.getChildren().addAll( mismatchTransition(), new ParallelTransition(moveLabel(period * rectWidth, ONE_SEC ), moveRectsBasedLabel((l + 1) * rectWidth, ONE_SEC ) ), setRectBWidth(1));
                    sp = sp+period; // new starting position in text
                    s = m-period-1; // update memory
                }
                else { // ----x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-------MISMATCH FORWARDS
                    int jump = (j-l);
                    animSequence.getChildren().addAll(mismatchTransition());
                    if ( j > (l+1) )
                        animSequence.getChildren().addAll( new ParallelTransition( moveLabel(jump * rectWidth, ONE_SEC), moveRectsBasedLabel( rectWidth * (l+1), ONE_SEC) ), setRectBWidth(1) );
                    else
                        animSequence.getChildren().addAll( new ParallelTransition( moveRectsA( rectWidth * jump, ONE_SEC ), moveRectsB( rectWidth * jump, ONE_SEC ), moveLabel( rectWidth * jump, ONE_SEC ) ), setRectBWidth(1) );

                    sp = sp + jump; // new starting position in text
                    s = -1; // update memory
                } // end if

            } // end of while loop

        } else { // first part of pattern is not a suffix
// ----------------------------------------------------------------------------------------------------------------------------------------------
            period = Math.max(l+1, m-(l+1)) + 1; // value of period

            System.out.println("PERIOD = " + period);
            // while we have not reached the end of text and a result hasn't been found
            while ( sp <= n-m && result < 0 ) {
                // search forwards...--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->
                j = l+1; // start from position l+1 in pattern
                while ( j < m && pattern[j] == text[sp+j]) { // check current chars
                    animSequence.getChildren().addAll( hideOrangeRect() );
                    if (j == (l + 1)) animSequence.getChildren().add( showGreenRect() );
                    else animSequence.getChildren().add( incrementRectBWidth() );
                    animSequence.getChildren().add( new PauseTransition( ONE_SEC ) );

                    j++; // move to next position in pattern

                    if ( j < m ) animSequence.getChildren().addAll( moveOrangeRect(rectWidth), new PauseTransition(HALF_SEC) );
                } // finished forwards search...--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->--->

                if (j >= m)
                { // reached end of pattern so search backwards
                    // search backwards...<-----<------<------<-----<------<------<-----<------<------<-----<------
                    j = l; // starting position in pattern


                    animSequence.getChildren().addAll(
                            moveOrangeRect( ( l - (m-1) ) * rectWidth ),
                            new PauseTransition( HALF_SEC )
                    );

                    while ( j >= 0 && pattern[j] == text[sp+j]) { // check current chars
                        animSequence.getChildren().addAll( hideOrangeRect(), moveRectsB(-rectWidth, Duration.ONE), setRectBWidth( m - j ), new PauseTransition( HALF_SEC ) );

                        if ( j != 0 && j < m ) // if match not found and text not finished
                            animSequence.getChildren().addAll(
                                    moveOrangeRect(-rectWidth),
                                    new PauseTransition( HALF_SEC )
                            );

                        j--; // move to previous position in pattern
                    }// finished searching backwards...<-----<------<------<-----<------<------<-----<------<------
                    if ( j < 0 ) { // reached start of pattern so a match
                        result = sp; break;
                    }
// ----x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-------MISMATCH BACKWARDS
                    animSequence.getChildren().addAll( mismatchTransition(), new ParallelTransition( moveLabel( period * rectWidth, ONE_SEC ), moveRectsBasedLabel( (l+1) * rectWidth, ONE_SEC ) ), setRectBWidth(1));
                    sp = sp + period; // new starting position in text
                }
                else { // ----x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-x-------MISMATCH FORWARDS
                    int jump = (j-l);
                    animSequence.getChildren().addAll(mismatchTransition());
                    if (j > (l+1))
                        animSequence.getChildren().addAll( new ParallelTransition( moveLabel( jump * rectWidth, ONE_SEC ), moveRectsBasedLabel( rectWidth * (l+1), ONE_SEC) ), setRectBWidth(1) );
                    else
                        animSequence.getChildren().addAll( new ParallelTransition( moveRectsA( rectWidth * jump, ONE_SEC ), moveRectsB( rectWidth * jump, ONE_SEC ), moveLabel( rectWidth * jump, ONE_SEC ) ), setRectBWidth(1) );
                    sp = sp + jump; // new starting position in text
                }
            } // end while
        } // end else (first part not suffix

        return animSequence;
    }

    /**************************************************************
     * Returns max suffix and period for => ordering
     *************************************************************/
    private int[] maxSuf2() {
        int i = -1, j = 0, k = 1, p = 1;
        char a, b;

        int m = this.pattern.length;

        while ( (j+k) <= m-1 ) {
            b = pattern[i+k];
            a = pattern[j+k];

            // case 1
            if (a > b){
                j = j+k;
                k = 1;
                p = j-i;
            }
            // case 2
            if (a == b){
                if (k == p) {
                    j = j+p;
                    k = 1;
                } else {
                    k = k + 1;
                }
            }
            // case 3
            if (a < b) {
                i = j;
                j = i + 1;
                k = 1;
                p = 1;
            }
        } // end while

        int[] limits = new int[2];
        limits[0] = i;
        limits[1] = p;

        return limits;
    }

    /***************************************************************
     * Returns max suffix and period for <= ordering
     **************************************************************/
    private int[] maxSuf1() {
        int i = -1, j = 0, k = 1, p = 1;
        char a, b;

        int m = this.pattern.length;

        while ( (j+k) <= m-1 ) {

            b = pattern[i+k];
            a = pattern[j+k];

            // case 1
            if (a < b){
                j = j+k;
                k = 1;
                p = j-i;
            }
            // case 2
            if (a == b){
                if (k == p) {
                    j = j+p;
                    k = 1;
                } else {
                    k = k + 1;
                }
            }
            // case 3
            if (a > b) {
                i = j;
                j = i + 1;
                k = 1;
                p = 1;
            }
        } // end while

        int[] limits = new int[2];
        limits[0] = i;
        limits[1] = p;

        return limits;
    }

    /****************************************************
     * Set the pattern text and populate the list
     * @param pattern - the search text
     * @return boolean - successful or not
     ***************************************************/
    @Override public boolean setPatternText( String pattern ) {

        super.setPatternText(pattern);

        if ( !pattern.isEmpty() ){
            limits1 = maxSuf1(); // max suffix for <= ordering
            limits2 = maxSuf2(); // max suffix for => ordering
//            this.createLastCharArray();
//            this.populateLists();
        }

        return true;
    }

}
