package model;

import javafx.animation.ParallelTransition;
import javafx.animation.PauseTransition;
import javafx.animation.SequentialTransition;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.shape.Rectangle;

public class BruteForceAlgo extends Visualisable {

    /****************************************************
     * Default Constructor
     ***************************************************/
    public BruteForceAlgo(Rectangle textRectA, Rectangle patternRectA, Rectangle textRectB, Rectangle patternRectB,
                          Label patternLabel, ListView codeView, ListView infoView) {
        super(textRectA, patternRectA, textRectB, patternRectB, patternLabel, codeView, infoView);

        // Populate ListViews with the appropriate data
        loadAlgoData(BF_TXT);
    }

    /*****************************************************************************************
     * Create the animation
     * @return SequentialTransition the sequence of animations
     ****************************************************************************************/
    @Override public SequentialTransition getAnimation() {

        // The centralAnimation which will store all sub-Animations
        SequentialTransition animSequence = new SequentialTransition();
        // Initialize X-coordinates of the Rectangles
        this.setXCoordinates();
        // Store the searchText and patternText length
        int m = pattern.length, n = text.length;
        // Initialize all indexes at 0
        int searchIndex = 0, i = 0, j = 0;


        // While pattern hasn't been found and not reached end of text/string
        while ( searchIndex <= n-m && j < m ) {

            animSequence.getChildren().addAll(
                    new PauseTransition( HALF_SEC ),
                    highlightCodeRow( ZERO,6,7 )
            );

            if (text[i] == pattern[j]) { // if chars match

                animSequence.getChildren().addAll(
                        highlightCodeRow( HALF_SEC, 8 ),
                        highlightCodeRow( HALF_SEC , 9,10 ),
                        hideOrangeRect() // Remove the orange Rectangles
                );

                // Show the other green Rectangles
                if (j == 0) animSequence.getChildren().add( showGreenRect() );
                // else increase the size to highlight one more character
                else animSequence.getChildren().add( setRectBWidth( j + 1 ) );
                // Pause for half a second
                animSequence.getChildren().add( new PauseTransition( ONE_SEC ) );

                i++; j++; // move on in text and pattern

                if (searchIndex <= n - m && j < m)
                    animSequence.getChildren().addAll(
                            moveOrangeRect(rectWidth),
                            new PauseTransition(HALF_SEC)
                    );
            }
            else { // if there is a mismatch
                // Add the transitions to the general sequence
                animSequence.getChildren().addAll(
                        highlightCodeRow( HALF_SEC, 11 ),
                        highlightCodeRow( HALF_SEC, 12,13,14 ),
                        mismatchTransition() );
                if (j > 0) animSequence.getChildren().addAll(moveOrangeRect(-j * rectWidth));
                animSequence.getChildren().addAll(
                        new ParallelTransition(
                                moveRectsA( rectWidth, ONE_SEC ),
                                moveRectsB( rectWidth, ONE_SEC ),
                                moveLabel( rectWidth, ONE_SEC ) ),
                        setRectBWidth( 1 ) );

                j = 0; // start again in string
                searchIndex++; // advance search index
                i = searchIndex; // back up in text to new search index
            }
        }

        // Highlight the lines determining the result
        animSequence.getChildren().add(highlightCodeRow( HALF_SEC, 16 ));
        if (j == m ) animSequence.getChildren().add( highlightCodeRow( HALF_SEC, 16, 17) );
        else animSequence.getChildren().add( highlightCodeRow( HALF_SEC, 18, 19) );

        // Store the result
        result = ( j == m ? searchIndex : -1 );

        return animSequence;
    }
}